package com.green.Datapractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatapracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatapracticeApplication.class, args);
	}

}
