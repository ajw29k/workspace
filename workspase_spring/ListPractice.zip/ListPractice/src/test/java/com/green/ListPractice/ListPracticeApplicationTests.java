package com.green.ListPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
