package com.green.CarSell;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarSellApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarSellApplication.class, args);
	}

}
