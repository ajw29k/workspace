package com.green.CarSell;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarSellApplicationTests {

	@Test
	void contextLoads() {
	}

}
