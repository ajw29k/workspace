package com.green.ReactStudent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactStudentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactStudentApplication.class, args);
	}

}
