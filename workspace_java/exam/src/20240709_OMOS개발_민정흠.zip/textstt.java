package test;

public class textstt {
    public static void main(String[] args) {
        Bank bank = new Bank();
        bank.getClient("1111-1111","이순신");
    }
}
