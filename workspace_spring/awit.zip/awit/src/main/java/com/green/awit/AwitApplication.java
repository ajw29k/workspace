package com.green.awit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwitApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwitApplication.class, args);
	}

}
