package com.green.ReactOder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactOderApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactOderApplication.class, args);
	}

}
