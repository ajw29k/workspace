package com.example.demodddddddddd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoddddddddddApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoddddddddddApplication.class, args);
	}

}
