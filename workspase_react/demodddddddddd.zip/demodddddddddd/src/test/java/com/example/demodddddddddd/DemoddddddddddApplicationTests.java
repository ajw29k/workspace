package com.example.demodddddddddd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoddddddddddApplicationTests {

	@Test
	void contextLoads() {
	}

}
